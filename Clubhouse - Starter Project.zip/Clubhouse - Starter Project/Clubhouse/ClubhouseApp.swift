//
//  ClubhouseApp.swift
//  Clubhouse
//
//  Created by Tunde on 28/02/2021.
//

import SwiftUI

@main
struct ClubhouseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(RoomViewModel())
        }
    }
}
