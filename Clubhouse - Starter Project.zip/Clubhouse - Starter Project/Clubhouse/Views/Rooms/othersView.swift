//
//  othersView.swift
//  Clubhouse
//
//  Created by rutik maraskolhe on 26/09/21.
//

import SwiftUI

struct othersView: View {
    
    let title: String
    let people: [Person]
    
    private let othersColumn = [
        GridItem(.fixed(65), spacing: 24),
        GridItem(.fixed(65), spacing: 24),
        GridItem(.fixed(65), spacing: 24),
        GridItem(.fixed(65), spacing: 24)
        
    ]
    
    var body: some View {
        
        VStack(alignment: .leading) {
            Text(title)
                .font(Font.Nunito.bold(size: 14))
                .foregroundColor(Color.customLightGray)
            
            LazyVGrid(columns: othersColumn, alignment: .leading,spacing: 10) {
                
                ForEach(people) { person in
                    otherPersonView(person: person)
                }
            }
        }
        .padding(.top,20)
        .padding(.horizontal, 25)
    }
}

struct othersView_Previews: PreviewProvider {
    static var previews: some View {
        othersView(title: "Other People",  people: FeedRoom.dummyData[0].othersInRoom)
    }
}
